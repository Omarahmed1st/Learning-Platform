 const searchicon1 = document.querySelector('#searchicon1');
const srchicon1 = document.querySelector('#srchicon1');
const search1 = document.querySelector('#searchinput1');
searchicon1.addEventListener('click', function() {
    search1.style.display = 'flex'
    searchicon1.style.display = 'none';

})


const searchicon2 = document.querySelector('#searchicon2');
const srchicon2 = document.querySelector('#srchicon2');
const search2 = document.querySelector('#searchinput2');
searchicon2.addEventListener('click', function() {
    search2.style.display = 'flex'
    searchicon2.style.display = 'none';

})
const bar = document.querySelector('.fa-bars');
const cross = document.querySelector('#hdcross');
const headerbar = document.querySelector('.headerbar');

bar.addEventListener('click', function() {
    setTimeout(() => {
        cross.style.display = 'block';
    }, 200);
    headerbar.style.right = '0%';
})

cross.addEventListener('click', function() {
    cross.style.display = 'none';
    headerbar.style.right = '-100%';
})

const performSearch = (searchFieldId) => {
    const searchField = document.getElementById(searchFieldId);
    const query = searchField.value.trim().toLowerCase();
    if (query === "menu") {
        window.location.href = "#Menu.html"; 
    } else {
        alert("No results found for: " + query);
    }
}

const searchBtn1 = document.getElementById('searchBtn1');
const searchBtn2 = document.getElementById('searchBtn2');

searchBtn1.addEventListener('click', () => performSearch('searchField1'));
searchBtn2.addEventListener('click', () => performSearch('searchField2'));